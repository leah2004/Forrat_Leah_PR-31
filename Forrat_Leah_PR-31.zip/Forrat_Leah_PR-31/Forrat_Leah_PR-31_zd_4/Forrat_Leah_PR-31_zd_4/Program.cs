﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Forrat_Leah_PR_31_zd_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] inputLines = File.ReadAllLines("input.txt");
            string[] sizes = inputLines[0].Split(' ');
            int messageLength = int.Parse(sizes[0]);
            int newspaperLength = int.Parse(sizes[1]);

            string message = inputLines[1];
            string newspaper = inputLines[2];

            string[] messageWords = message.Split(' ');
            string[] newspaperWords = newspaper.Split(' ');
            Dictionary<string, int> wordCount = new Dictionary<string, int>();
            foreach (var word in newspaperWords)
            {
                if (wordCount.ContainsKey(word))
                {
                    wordCount[word]++;
                }
                else
                {
                    wordCount[word] = 1;
                }
            }

            foreach (var word in messageWords)
            {
                if (wordCount.ContainsKey(word) && wordCount[word] > 0)
                {
                    wordCount[word]--; 
                }
                else
                {
                    File.WriteAllText("output.txt", word);
                    return;
                }
            }
            File.WriteAllText("output.txt", "GOOD NOTE");

        }
    }
}
