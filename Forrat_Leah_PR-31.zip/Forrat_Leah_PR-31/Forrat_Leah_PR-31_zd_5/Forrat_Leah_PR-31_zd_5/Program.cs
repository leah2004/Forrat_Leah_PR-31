﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Forrat_Leah_PR_31_zd_5
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string[] inputLines = File.ReadAllLines("input.txt");
            int N = int.Parse(inputLines[0]); 
            string[] parameters = inputLines[1].Split(' ');
            int V = int.Parse(parameters[0]); 
            int t = int.Parse(parameters[1]); 

            int distance = V * t;

            int K = distance % N;
            File.WriteAllText("output.txt", K.ToString());
        }
    }
}
